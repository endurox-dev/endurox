#ifndef TEXT_REPORTER_HEADER
#define TEXT_REPORTER_HEADER

#ifdef __cplusplus
  extern "C" {
#endif

#include <cgreen/reporter.h>

TestReporter *create_text_reporter(void);

#ifdef __cplusplus
    }
#endif


#endif

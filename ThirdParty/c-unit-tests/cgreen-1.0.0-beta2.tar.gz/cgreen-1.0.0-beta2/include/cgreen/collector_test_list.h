#ifndef COLLECTOR_TEST_LIST_HEADER
#define COLLECTOR_TEST_LIST_HEADER

void create_test_list();
void destroy_test_list();
void add_to_test_list(char *test_name);
void reset_test_list();
void print_test_list();

#endif

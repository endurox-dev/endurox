#ifndef UTILS_HEADER
#define UTILS_HEADER

#ifdef __cplusplus
namespace cgreen {
    extern "C" {
#endif

char *string_dup(const char *original);

#ifdef __cplusplus
    }
}
#endif

#endif
